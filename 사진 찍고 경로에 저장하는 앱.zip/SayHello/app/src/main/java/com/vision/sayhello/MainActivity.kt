package com.vision.sayhello

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import com.vision.sayhello.databinding.ActivityMainBinding
import java.io.File
import java.nio.file.Files.createFile
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

//typealias  별칭 설정
// 함수이름 과 매개변수와 타입, 반환 타입 선언
typealias LumaListener = (luma : Double) -> Unit

class MainActivity : AppCompatActivity() {
    // findview는 작업량이 많으므로 적게 써야한다.
    // lateinit 작업 호출전에 초기화될것이라고 약속
    // 코드 전체에서 사용가능
    // findview 대신 viewbinding 사용
    private lateinit var viewBinding: ActivityMainBinding
    private var imageCapture : ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    // ExecutorService 병렬처리를 위한 쓰레드풀 생성
    private lateinit var cameraExecutor: ExecutorService

    private lateinit var outputDirectory: File
    private val PHOTO_EXTENSION = ".jpg"

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityMainBinding.inflate(layoutInflater)
        // viewbinding 사용시 setcontentview 는 반드시 viewBinding.root 로 해야함
        setContentView(viewBinding.root)



        // 카메라 권한 요청 확인
        if (allPermissionsGranted()){
            startCamera()
        } else {// requestPermissions 권한 요청 CODE로 응답 정달
            ActivityCompat.requestPermissions(
                this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS)
        }



        // 사진 , 비디오 촬영 버튼 이벤트
        viewBinding.imageCaptureButton.setOnClickListener { takePhoto("0") }
        viewBinding.captureButton1.setOnClickListener { takePhoto("1") }

        // 카메라 실행 쓰레드 ExecutorService  객체 생성
        //newSingleThreadExecutor 스레드가 1개인 ExecutorService를 리턴한다. 싱글 스레드에서 동작해야 하는 작업을 처리할 때 사용한다.
        cameraExecutor = Executors.newSingleThreadExecutor()
    }
    // 사진 찍기
    @RequiresApi(Build.VERSION_CODES.O)
    private fun takePhoto(folderName : String) {
        //이미지 캡처가 설정되기 전에 사진 버튼을 탭하면 null이 됩니다. return 문이 없으면 앱이 null인 경우 충돌이 발생합니다.
        val imageCapture = imageCapture ?: return
        //저장 경로
        outputDirectory = getOutputDirectory(baseContext , folderName)
        val photoFile = createFile(outputDirectory, Companion.FILENAME, PHOTO_EXTENSION)


        // 이미지를 보관할 MediaSore 콘텐츠 생성
        val name = SimpleDateFormat(FILENAME_FORMAT, Locale.KOREA)
            .format(System.currentTimeMillis())
        val contentValues = ContentValues().apply{
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if(Build.VERSION.SDK_INT > Build.VERSION_CODES.P){
                put(MediaStore.Images.Media.RELATIVE_PATH , "Pictures/CameraX-Image")
            }
        }
        // 이미지 출력에 관한 옵션,
        val outputOptions = ImageCapture.OutputFileOptions
            .Builder(photoFile)
            .build()

        // 이미지 캡쳐시  저장시 outputOptions ,실행자(쓰레드) 및 콜백 전달
        imageCapture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                // 저장실패시 로그
                override fun onError(exc: ImageCaptureException) {
                    Log.e(TAG, "Photo capture failed: ${exc.message}", exc)
                }
                // 이미지 캡쳐 성공시 파일 저장 및 로그 출력
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    val msg = "Photo capture succeeded: ${output.savedUri}"
                    Toast.makeText(baseContext, msg, Toast.LENGTH_SHORT).show()
                    Log.d(TAG, msg)
                }
            }
        )
    }

    private fun captureVideo() {}

    // 카메라 시작
    private fun startCamera() {
        // 카메라 바인딩
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            // 카메라의 수명 주기를 소유자에 바인딩
            val cameraProvider : ProcessCameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder()
                .build()
                .also{
                    //SurfaceProvider 데이터를 받을 준비되었다는 신호를 카메라에데 보내줌
                    it.setSurfaceProvider(viewBinding.viewFinder.surfaceProvider)
                }

            imageCapture = ImageCapture.Builder().build()

            // 기본 후면 카메라 설정
            var cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
            // try에서 cameraProvider이 바인딩 된것이 없는지 확인 후 바인딩
            try{
                cameraProvider.unbindAll()

                // 사용 주기 카메라 , 프리뷰, 이미지 캡쳐를 같이 바인딩딩
               cameraProvider.bindToLifecycle(
                    this, cameraSelector, preview, imageCapture)
            } catch(exc: Exception) { // 실패시 로그
                Log.e(TAG, "Use case binding failed", exc)
            }
        }, ContextCompat.getMainExecutor(this)
        )// getMainExcutor 메인 쓰레드 하나 할당
    }

    //앱 권한 답변 확인
    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults:
        IntArray) {
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (allPermissionsGranted()) {
                startCamera()
            } else {
                Toast.makeText(this,
                    "Permissions not granted by the user.",
                    Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    //앱 권한 확인 함수
    // all 모든 원소가 함수 만족하는지 체크
    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all{
        ContextCompat.checkSelfPermission(
            baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    // 앱 꺼질 떄
    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }

    // 전역에서 쓸수 있는 객체들
    companion  object {
        private const val TAG = "CameraXApp"
        private const val FILENAME_FORMAT = "yyyy-MM-dd-HH-mm-ss-SSS"
        private const val REQUEST_CODE_PERMISSIONS = 10
        // mutableListOf 읽기 쓰기 가능한 리스트 동적 할당 가능
        // VERSION.SDK_INT 구동 장치 os버전 VERSION_CODES.P Pie os 버전
        // toTypedArray 배열 변환
         private val REQUIRED_PERMISSIONS =
            mutableListOf (
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO
            ).apply {
                if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
                    add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                }
            }.toTypedArray()

        /** 외부미디어 사용, 아니면 앱의 파일 디렉토리 */
        fun getOutputDirectory(context: Context , fname : String): File {
            val appContext = context.applicationContext

            val mediaDir = context.externalMediaDirs.firstOrNull()?.let {
                //appContext.resources.getString(R.string.app_name)
                File(it, fname).apply { mkdirs() } }
            return if (mediaDir != null && mediaDir.exists())
                mediaDir else appContext.filesDir
        }

        private fun createFile(baseFolder: File, format: String, extension: String) =
            File(baseFolder, SimpleDateFormat(format, Locale.US)
                .format(System.currentTimeMillis()) + extension)

        private const val FILENAME = "yyyy-MM-dd-HH-mm-ss-SSS"

    }
}




